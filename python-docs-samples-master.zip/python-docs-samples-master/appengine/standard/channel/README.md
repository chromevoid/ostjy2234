To deploy, run the following command, or see [here](https://cloud.google.com/appengine/docs/python/gettingstartedpython27/uploading) for more details about uploading your application.

`appcfg.py -A <YOUR_PROJECT_ID> update .`

