# Google App Engine Namespaces

This sample demonstrates how to use Google App Engine's [Namespace Manager API](https://cloud.google.com/appengine/docs/python/multitenancy/multitenancy).

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/multitenancy/multitenancy

<!-- end-auto-doc-link -->

Refer to the [App Engine Samples README](../README.md) for information on how to run and deploy this sample.
