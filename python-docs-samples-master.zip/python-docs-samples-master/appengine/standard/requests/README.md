## App Engine Requests Docs Snippets

These snippets demonstrate various aspects of App Engine Python request handling.

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/how-requests-are-handled

<!-- end-auto-doc-link -->
