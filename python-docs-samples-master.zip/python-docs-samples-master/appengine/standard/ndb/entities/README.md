## App Engine Datastore NDB Entities Samples

This contains snippets used in the NDB entity documentation, demonstrating
various operations on ndb entities.

<!-- auto-doc-link -->
These samples are used on the following documentation pages:

>
* https://cloud.google.com/appengine/docs/python/datastore/creating-entities
* https://cloud.google.com/appengine/docs/python/datastore/creating-entity-models
* https://cloud.google.com/appengine/docs/python/users/userobjects
* https://cloud.google.com/appengine/docs/python/datastore/creating-entity-keys

<!-- end-auto-doc-link -->
