## App Engine Datastore NDB Properties Samples

This contains snippets used in the NDB properties documentation, demonstrating
various operations on ndb properties.

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/datastore/entity-property-reference

<!-- end-auto-doc-link -->
