## App Engine Datastore NDB Property Subclasses Samples

This contains snippets used in the NDB property subclasses documentation,
demonstrating various operations on ndb property subclasses.

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/ndb/subclassprop

<!-- end-auto-doc-link -->
