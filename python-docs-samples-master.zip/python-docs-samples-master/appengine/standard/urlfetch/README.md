## App Engine UrlFetch Docs Snippets

This sample application demonstrates different ways to request a URL
on App Engine


<!-- auto-doc-link --><!-- end-auto-doc-link -->
