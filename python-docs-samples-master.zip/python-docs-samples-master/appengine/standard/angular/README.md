## App Engine & Angular JS

A simple [AngularJS](http://angularjs.org/) CRUD application for [Google App Engine](https://appengine.google.com/).

Refer to the [App Engine Samples README](../README.md) for information on how to run and deploy this sample.
