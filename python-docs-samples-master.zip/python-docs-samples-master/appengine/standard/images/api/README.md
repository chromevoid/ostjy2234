## Images Guestbook Sample

This is a sample app for Google App Engine that demonstrates the [Images Python
API](https://cloud.google.com/appengine/docs/python/images/usingimages).

<!-- auto-doc-link -->
These samples are used on the following documentation page:

> https://cloud.google.com/appengine/docs/python/images/

<!-- end-auto-doc-link -->

Refer to the [App Engine Samples README](../../README.md) for information on how to run and deploy this sample.
